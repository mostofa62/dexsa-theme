jQuery('#bootstrapslider').carousel({
	 interval: bootstrapslider_script_vars.interval,
	 pause: bootstrapslider_script_vars.pause,
	 wrap: bootstrapslider_script_vars.wrap
});
